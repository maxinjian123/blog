const express = require('express')
const {auth, adminOnly} = require('../middleware/auth')
const {success, error, paginated} = require('../utils/response')
const {Tag, Article, User} = require('../models')
const {Sequelize, Op, literal} = require('sequelize')
const {sequelize} = require('../models')
const redis = require('../utils/redis')

const router = express.Router()

// 清除热门标签缓存（标签增删改时调用）
function clearHotTagsCache() {
  if (redis.status !== 'ready') return
  redis.keys('blog:hot:tags:*').then(keys => {
    if (keys && keys.length) redis.del(...keys)
  }).catch(() => {})
}

router.get('/', async (req, res, next) => {
    try {
        const All = req.header('All')
        const page = parseInt(req.query.page) || 1
        const pageSize = parseInt(req.query.pageSize) || 10
        const sort = req.query.sort || 'id'
        const order = req.query.order || 'ASC'
        const keyword = req.query.keyword || ''

        const where = {}
        if (keyword) {
            where[Op.or] = [{name: {[Op.like]: `%${keyword}%`}}, {slug: {[Op.like]: `%${keyword}%`}}]
        }
        const offset = (page - 1) * pageSize

        const articleCountLiteral = literal(`(
      SELECT COUNT(*)
      FROM article_tags
      WHERE article_tags.tag_id = Tag.id
    )`)

        const sortOrder = [[sort === 'articleCount' ? literal('articleCount') : sort, order]]

        const queryOptions = {
            attributes: {
                include: [[articleCountLiteral, 'articleCount']]
            },
            where,
            order: sortOrder
        }

        if (All !== 'true') {
            queryOptions.limit = pageSize
            queryOptions.offset = offset
        }

        const {count, rows} = await Tag.findAndCountAll(queryOptions)

        return paginated(res, {list: rows, total: count, page, pageSize})
    } catch (err) {
        next(err)
    }
})

/**
 * 热门标签（结合 Redis 缓存动态计算，按关联文章数降序）
 * GET /tags/hot?limit=20
 * 缓存 key: blog:hot:tags:<limit>，TTL 10 分钟
 */
router.get('/hot', async (req, res, next) => {
  const limit = Math.min(Math.max(parseInt(req.query.limit) || 20, 1), 100)
  const cacheKey = `blog:hot:tags:${limit}`
  try {
    if (redis.status === 'ready') {
      const cached = await redis.get(cacheKey).catch(() => null)
      if (cached) {
        try { return success(res, JSON.parse(cached)) } catch (_) { /* 解析失败回源 */ }
      }
    }

    // 关联已发布文章数
    const rows = await Tag.findAll({
      attributes: [
        'id', 'name', 'slug',
        [literal(`(
          SELECT COUNT(*)
          FROM article_tags at
          INNER JOIN articles a ON a.id = at.article_id AND a.status = 'published'
          WHERE at.tag_id = Tag.id
        )`), 'article_count']
      ],
      having: literal(`(
        SELECT COUNT(*)
        FROM article_tags at
        INNER JOIN articles a ON a.id = at.article_id AND a.status = 'published'
        WHERE at.tag_id = Tag.id
      ) > 0`),
      order: [[literal('article_count'), 'DESC']],
      limit,
      raw: true
    })

    if (redis.status === 'ready') {
      redis.set(cacheKey, JSON.stringify(rows), 'EX', 600).catch(() => {})
    }
    return success(res, rows)
  } catch (err) {
    next(err)
  }
})

router.get('/:id/articles', async (req, res, next) => {
    try {
        const tagId = req.params.id
        const page = parseInt(req.query.page) || 1
        const pageSize = parseInt(req.query.pageSize) || 10
        const keyword = req.query.keyword || ''

        const tag = await Tag.findByPk(tagId)
        if (!tag) {
            return error(res, '标签不存在', 404)
        }

        const where = {}
        if (keyword) {
            where[Op.or] = [{title: {[Op.like]: `%${keyword}%`}}, {status: {[Op.like]: `%${keyword}%`}}]
        }

        const {count, rows} = await Article.findAndCountAll({
            include: [
                {
                    model: Tag,
                    as: 'tags',
                    where: {id: tagId},
                    through: {attributes: []}
                },
                {
                    model: User,
                    as: 'author',
                    attributes: ['id', 'username', 'avatar']
                }
            ],
            where,
            attributes: ['id', 'title', 'status', 'summary', 'view_count', 'published_at', 'created_at', 'cover'],
            distinct: true,
            order: [['created_at', 'DESC']],
            limit: pageSize,
            offset: (page - 1) * pageSize
        })

        return paginated(res, {list: rows, total: count, page, pageSize})
    } catch (err) {
        next(err)
    }
})

router.post('/', auth, adminOnly, async (req, res, next) => {
    try {
        const {name, slug} = req.body

        if (!name) {
            return error(res, '标签名称不能为空', 400)
        }

        const tag = await Tag.create({
            name,
            slug: slug || name.toLowerCase().replace(/\s+/g, '-')
        })
        clearHotTagsCache()

        return success(res, tag, '标签创建成功', 201)
    } catch (err) {
        next(err)
    }
})

router.put('/:id', auth, adminOnly, async (req, res, next) => {
    try {
        const tag = await Tag.findByPk(req.params.id)
        if (!tag) {
            return error(res, '标签不存在', 404)
        }

        const {name, slug} = req.body

        await tag.update({
            name: name || tag.name,
            slug: slug || tag.slug
        })
        clearHotTagsCache()

        return success(res, tag, '标签更新成功')
    } catch (err) {
        next(err)
    }
})

router.delete('/:id', auth, adminOnly, async (req, res, next) => {
    try {
        const tag = await Tag.findByPk(req.params.id)
        if (!tag) {
            return error(res, '标签不存在', 404)
        }

        await tag.destroy()
        clearHotTagsCache()

        return success(res, null, '标签删除成功')
    } catch (err) {
        next(err)
    }
})

module.exports = router
